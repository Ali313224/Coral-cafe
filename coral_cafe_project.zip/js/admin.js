
const correctPassword = "alishams193";
function checkPassword() {
    const passwordInput = document.getElementById('password').value;
    if (passwordInput === correctPassword) {
        document.getElementById('login').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
        loadItems();
    } else {
        alert('كلمة المرور خاطئة');
    }
}
document.getElementById('itemForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const category = document.getElementById('category').value;
    const price = document.getElementById('price').value;
    const imageInput = document.getElementById('image');
    const reader = new FileReader();
    reader.onload = function() {
        const newItem = {
            name,
            category,
            price,
            image: reader.result
        };
        const items = JSON.parse(localStorage.getItem('menuItems')) || [];
        items.push(newItem);
        localStorage.setItem('menuItems', JSON.stringify(items));
        alert('تمت إضافة الصنف!');
        window.location.reload();
    };
    reader.readAsDataURL(imageInput.files[0]);
});
function loadItems() {
    const itemsList = document.getElementById('itemsList');
    const items = JSON.parse(localStorage.getItem('menuItems')) || [];
    itemsList.innerHTML = '';
    items.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'menu-item';
        div.innerHTML = `
            <img src="${item.image}" alt="${item.name}" style="width:100px;height:100px;object-fit:cover;">
            <h3>${item.name}</h3>
            <p>${item.category}</p>
            <p>${item.price} ريال</p>
            <button onclick="deleteItem(${index})">حذف</button>
        `;
        itemsList.appendChild(div);
    });
}
function deleteItem(index) {
    const items = JSON.parse(localStorage.getItem('menuItems')) || [];
    items.splice(index, 1);
    localStorage.setItem('menuItems', JSON.stringify(items));
    alert('تم حذف الصنف!');
    window.location.reload();
}
