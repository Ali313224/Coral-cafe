
document.addEventListener('DOMContentLoaded', () => {
    const menuContainer = document.getElementById('menu');
    const items = JSON.parse(localStorage.getItem('menuItems')) || [];
    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'menu-item';
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p>${item.category}</p>
            <p>${item.price} ريال</p>
        `;
        menuContainer.appendChild(itemDiv);
    });
});
